<?php
$route['accounts/financial-year'] = "accounts/Accounts/financial-year/";